(function init(){
// Write your own code here



})();