# Remap Makey Makey Keys

## Easy method
http://makeymakey.com/remap
Follow the instructions

## Arduino method
- Open Arduino IDE
- Install the Makey Makey Add-on using the Arduino board manager
- Choose the Makey Makey in Tools > Boards
- Choose the right Serial Port in Tools > Serial Port
- Open the code makey_makey.ino
- Change the keys as you want in the settings.h file 
- Send the code to the Makey Makey
